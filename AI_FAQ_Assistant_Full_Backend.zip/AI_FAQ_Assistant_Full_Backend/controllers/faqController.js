const faqModel = require("../models/faqModel");
const aiService = require("../services/aiService");

const getFAQs = async (req, res, next) => {
  try {
    const faqs = await faqModel.getAll();
    res.json({ success: true, data: faqs });
  } catch (error) {
    next(error);
  }
};

const getFAQById = async (req, res, next) => {
  try {
    const faq = await faqModel.getById(req.params.id);
    if (!faq) {
      return res.status(404).json({
        success: false,
        message: "FAQ not found"
      });
    }
    res.json({ success: true, data: faq });
  } catch (error) {
    next(error);
  }
};

const createFAQ = async (req, res, next) => {
  try {
    const { question, answer, category } = req.body;

    if (!question || !answer) {
      return res.status(400).json({
        success: false,
        message: "Question and answer are required"
      });
    }

    const faq = await faqModel.create({ question, answer, category });
    res.status(201).json({ success: true, data: faq });
  } catch (error) {
    next(error);
  }
};

const askQuestion = async (req, res, next) => {
  try {
    const { question } = req.body;

    if (!question) {
      return res.status(400).json({
        success: false,
        message: "Question is required"
      });
    }

    const matches = await faqModel.search(question);

    if (matches.length > 0) {
      return res.json({
        success: true,
        answer: matches[0].answer,
        source: "FAQ Knowledge Base",
        matched_faq: matches[0]
      });
    }

    const answer = await aiService.generateAnswer(question);

    res.json({
      success: true,
      answer,
      source: "AI Service"
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getFAQs,
  getFAQById,
  createFAQ,
  askQuestion
};
