const express = require("express");
const router = express.Router();
const faqController = require("../controllers/faqController");
const authenticate = require("../middleware/authMiddleware");

router.get("/", faqController.getFAQs);
router.get("/:id", faqController.getFAQById);
router.post("/", authenticate, faqController.createFAQ);
router.post("/ask", faqController.askQuestion);

module.exports = router;
