// This service is intentionally kept separate from the controller.
// You can connect an AI provider/API here later without changing the routes.

const generateAnswer = async (question) => {
  return `I could not find this in the FAQ knowledge base. Your question was: "${question}"`;
};

module.exports = { generateAnswer };
