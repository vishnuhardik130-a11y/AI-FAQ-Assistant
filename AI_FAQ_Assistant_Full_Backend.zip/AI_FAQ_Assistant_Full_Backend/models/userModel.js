const db = require("../config/db");

const findByEmail = async (email) => {
  const [rows] = await db.query(
    "SELECT user_id, full_name, email, password_hash, role FROM users WHERE email = ?",
    [email]
  );
  return rows[0];
};

const createUser = async (fullName, email, passwordHash) => {
  const [result] = await db.query(
    "INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)",
    [fullName, email, passwordHash]
  );
  return result.insertId;
};

module.exports = { findByEmail, createUser };
