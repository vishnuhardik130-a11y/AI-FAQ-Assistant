const db = require("../config/db");

const getAll = async () => {
  const [rows] = await db.query(
    "SELECT faq_id, question, answer, category, created_at FROM faqs ORDER BY faq_id DESC"
  );
  return rows;
};

const getById = async (id) => {
  const [rows] = await db.query(
    "SELECT faq_id, question, answer, category, created_at FROM faqs WHERE faq_id = ?",
    [id]
  );
  return rows[0];
};

const create = async ({ question, answer, category }) => {
  const [result] = await db.query(
    "INSERT INTO faqs (question, answer, category) VALUES (?, ?, ?)",
    [question, answer, category || "General"]
  );
  return getById(result.insertId);
};

const search = async (keyword) => {
  const like = `%${keyword}%`;
  const [rows] = await db.query(
    "SELECT faq_id, question, answer, category FROM faqs WHERE question LIKE ? OR answer LIKE ? LIMIT 5",
    [like, like]
  );
  return rows;
};

module.exports = { getAll, getById, create, search };
