# Backend Development

## 1. Project Setup
The backend is developed using Node.js and Express.js.

## 2. Server Development
`server.js` creates the Express application, enables CORS and JSON parsing, registers API routes and starts the server.

## 3. Database Development
MySQL is used for persistent storage. Database configuration is kept in `config/db.js`.

## 4. Authentication
The authentication module provides registration and login. Passwords are hashed using bcryptjs and login creates a JWT token.

## 5. API Development
REST API endpoints are organized under the `routes` folder.

## 6. Controller Development
Controllers receive requests, validate data, call models/services and return JSON responses.

## 7. Model Development
Models contain database queries. This keeps SQL operations separate from the controller layer.

## 8. AI Service
`services/aiService.js` is a separate layer for connecting an AI provider later.

## 9. Error Handling
Errors are handled centrally and API responses use JSON.

## 10. Testing
Use Postman or Thunder Client to test registration, login, FAQ listing and question-answer APIs.
