# API Testing

## Start
npm install
npm run dev

## Health
GET http://localhost:5000/api/health

## Register
POST http://localhost:5000/api/auth/register

{
  "full_name": "Test User",
  "email": "test@example.com",
  "password": "123456"
}

## Login
POST http://localhost:5000/api/auth/login

{
  "email": "test@example.com",
  "password": "123456"
}

## Get FAQs
GET http://localhost:5000/api/faqs

## Ask Question
POST http://localhost:5000/api/faqs/ask

{
  "question": "What is AI?"
}

## Create FAQ
POST http://localhost:5000/api/faqs

Header:
Authorization: Bearer YOUR_JWT_TOKEN

Body:
{
  "question": "What is Node.js?",
  "answer": "Node.js is a JavaScript runtime used for server-side development.",
  "category": "Programming"
}
