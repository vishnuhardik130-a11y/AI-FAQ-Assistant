# GitHub Setup

Do not upload `.env` or `node_modules`.

Recommended commands:

git init
git add .
git commit -m "Initial AI FAQ Assistant backend"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main

Before pushing, create `.env` locally from `.env.example`.
