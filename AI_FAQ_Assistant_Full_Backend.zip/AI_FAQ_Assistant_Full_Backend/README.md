# AI FAQ Assistant - Full Backend

Naan Mudhalvan Backend Development Project.

## Technology
- Node.js
- Express.js
- MySQL
- REST API
- JWT Authentication
- bcryptjs
- CORS

## Folder Structure

backend/
├── config/
├── controllers/
├── database/
├── docs/
├── middleware/
├── models/
├── routes/
├── services/
├── .env.example
├── .gitignore
├── package.json
└── server.js

## Installation

1. Open this folder in VS Code.
2. Open Terminal.
3. Run:

npm install

4. Create `.env` from `.env.example` and enter your MySQL password.
5. Run `database/schema.sql` in MySQL Workbench.
6. Start:

npm run dev

Server:
http://localhost:5000

Health:
http://localhost:5000/api/health

## GitHub

Use the instructions in `docs/GITHUB_SETUP.md`.
Never upload `.env` or `node_modules`.
