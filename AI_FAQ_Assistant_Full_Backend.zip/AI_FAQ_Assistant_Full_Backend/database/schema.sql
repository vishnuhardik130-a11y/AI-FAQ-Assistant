CREATE DATABASE IF NOT EXISTS ai_faq_assistant;
USE ai_faq_assistant;

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS faqs (
  faq_id INT AUTO_INCREMENT PRIMARY KEY,
  question VARCHAR(500) NOT NULL,
  answer TEXT NOT NULL,
  category VARCHAR(100) DEFAULT 'General',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO faqs (question, answer, category) VALUES
('What is AI?', 'AI stands for Artificial Intelligence and enables computers to perform tasks that normally require human intelligence.', 'AI'),
('What is backend development?', 'Backend development manages server-side logic, APIs, databases and application processing.', 'Backend'),
('What is an API?', 'An API allows different software systems to communicate with each other.', 'Programming');
