require("dotenv").config();
const express = require("express");
const cors = require("cors");
const db = require("./config/db");
const faqRoutes = require("./routes/faqRoutes");
const authRoutes = require("./routes/authRoutes");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "AI FAQ Assistant Backend is running",
    version: "1.0.0"
  });
});

app.get("/api/health", async (req, res) => {
  try {
    await db.query("SELECT 1");
    res.json({ success: true, database: "connected" });
  } catch (error) {
    res.status(500).json({ success: false, database: "disconnected" });
  }
});

app.use("/api/auth", authRoutes);
app.use("/api/faqs", faqRoutes);

app.use((req, res) => {
  res.status(404).json({ success: false, message: "Route not found" });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({
    success: false,
    message: "Internal server error"
  });
});

app.listen(PORT, () => {
  console.log(`AI FAQ Assistant Backend running at http://localhost:${PORT}`);
});
